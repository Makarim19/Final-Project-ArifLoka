open class ArifLoka {
    protected var nama="Arif Rahmadisme"
    protected var NINaga =331132244324
    protected var tsd=15
    protected var bnyk=0
    var tanggal=""
    var pembayar=0
    var harga=0
    var kode=0
    var jenis=""
    var tanggalakhir=""
    open fun hotel(){

    }
    open fun pesawat(){

    }
    open fun kereta(){

    }
    open fun villa(){

    }
    fun show(){
        println("Nama = \t\t\t$nama")
        println("No Induk Naga = $NINaga")
    }
}