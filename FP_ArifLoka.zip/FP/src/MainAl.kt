fun main() {
    var loka=kontrol()
    loka.tol()
    loka.kon()
}